import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, f1_score
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    EarlyStoppingCallback
)
from datasets import Dataset
import torch
from torch.utils.data import DataLoader
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ModelTrainer:
    def __init__(self, model_dir="./models"):
        self.model_dir = model_dir
        os.makedirs(model_dir, exist_ok=True)

    def train_abuse_detector(self, dataset_path=None):
        """Train or fine-tune abuse detection model"""
        logger.info("Training abuse detection model...")

        # Load or create synthetic dataset
        if dataset_path and os.path.exists(dataset_path):
            df = pd.read_csv(dataset_path)
        else:
            df = self._create_synthetic_abuse_data()

        # Preprocess data
        texts = df['text'].tolist()
        labels = df['label'].tolist()

        # Split data
        train_texts, test_texts, train_labels, test_labels = train_test_split(
            texts, labels, test_size=0.2, random_state=42, stratify=labels
        )

        # Initialize tokenizer and model
        model_name = "cardiffnlp/twitter-roberta-base-offensive"
        tokenizer = AutoTokenizer.from_pretrained(model_name)

        # Tokenize data
        train_encodings = tokenizer(
            train_texts,
            truncation=True,
            padding=True,
            max_length=512
        )
        test_encodings = tokenizer(
            test_texts,
            truncation=True,
            padding=True,
            max_length=512
        )

        # Create datasets
        train_dataset = AbuseDataset(train_encodings, train_labels)
        test_dataset = AbuseDataset(test_encodings, test_labels)

        # Model configuration
        model = AutoModelForSequenceClassification.from_pretrained(
            model_name,
            num_labels=2
        )

        # Training arguments
        training_args = TrainingArguments(
            output_dir=os.path.join(self.model_dir, 'abuse_detector'),
            num_train_epochs=3,
            per_device_train_batch_size=8,
            per_device_eval_batch_size=8,
            warmup_steps=500,
            weight_decay=0.01,
            logging_dir='./logs',
            logging_steps=10,
            evaluation_strategy="steps",
            eval_steps=50,
            save_steps=100,
            load_best_model_at_end=True,
            metric_for_best_model="f1"
        )

        # Initialize trainer
        trainer = Trainer(
            model=model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=test_dataset,
            compute_metrics=self._compute_metrics,
            callbacks=[EarlyStoppingCallback(early_stopping_patience=3)]
        )

        # Train model
        trainer.train()

        # Save model
        trainer.save_model(os.path.join(self.model_dir, 'abuse_detector_final'))
        tokenizer.save_pretrained(os.path.join(self.model_dir, 'abuse_detector_final'))

        # Evaluate
        eval_results = trainer.evaluate()
        logger.info(f"Abuse detection model evaluation: {eval_results}")

        return model, tokenizer

    def _create_synthetic_abuse_data(self):
        """Create synthetic dataset for abuse detection"""
        logger.info("Creating synthetic abuse detection dataset...")

        data = []

        # Abusive examples
        abusive_examples = [
            "I hate you, you're worthless!",
            "You should die, nobody likes you!",
            "Stupid idiot, go away!",
            "I'm going to hurt you if you don't listen!",
            "You're such a loser, always failing!",
            "I'll make sure you regret this!",
            "Nobody cares about you, just disappear!",
            "You're pathetic and useless!",
            "I'm going to destroy your life!",
            "You deserve to be punished!",
            "I hope you suffer for what you did!",
            "You're nothing but trash!",
            "I'll teach you a lesson you'll never forget!",
            "You're the worst person I've ever met!",
            "I can't stand looking at your face!"
        ]

        # Non-abusive examples
        non_abusive_examples = [
            "Hello, how are you doing today?",
            "I appreciate your help with this project.",
            "Could you please explain that again?",
            "Thank you for your assistance.",
            "I'm looking forward to our meeting tomorrow.",
            "The weather is really nice today.",
            "I enjoyed reading that book you recommended.",
            "Let's work together on this task.",
            "I think we can find a good solution.",
            "Have a great day!",
            "I'm learning so much from this conversation.",
            "That's an interesting perspective.",
            "I understand your point of view.",
            "Let me know if you need any help.",
            "I'm happy to assist with your project."
        ]

        # Add abusive examples
        for text in abusive_examples:
            data.append({'text': text, 'label': 1})

        # Add non-abusive examples
        for text in non_abusive_examples:
            data.append({'text': text, 'label': 0})

        # Add more variations
        for i in range(50):
            data.append({
                'text': f"This is a normal conversation example {i}",
                'label': 0
            })
            data.append({
                'text': f"I really dislike this situation {i}",
                'label': 1 if i % 3 == 0 else 0
            })

        df = pd.DataFrame(data)
        df.to_csv(os.path.join(self.model_dir, 'synthetic_abuse_data.csv'), index=False)

        return df

    def _compute_metrics(self, eval_pred):
        """Compute metrics for evaluation"""
        predictions, labels = eval_pred
        predictions = np.argmax(predictions, axis=1)

        return {
            'accuracy': accuracy_score(labels, predictions),
            'f1': f1_score(labels, predictions, average='weighted'),
            'f1_macro': f1_score(labels, predictions, average='macro')
        }


class AbuseDataset(torch.utils.data.Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx])
        return item

    def __len__(self):
        return len(self.labels)


if __name__ == "__main__":
    trainer = ModelTrainer()

    # Train abuse detection model
    model, tokenizer = trainer.train_abuse_detector()

    print("Model training completed!")