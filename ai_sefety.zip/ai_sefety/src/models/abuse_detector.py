import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import numpy as np
from typing import Dict, Tuple


class AbuseDetector:
    def __init__(self, model_name="cardiffnlp/twitter-roberta-base-offensive"):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name)
        self.model.to(self.device)
        self.model.eval()

        # Abuse categories with severity scores
        self.abuse_categories = {
            'harassment': 0.7,
            'threat': 0.9,
            'hate_speech': 0.8,
            'mild_abuse': 0.4
        }

    def predict(self, text: str) -> Dict:
        """Detect abusive language in text"""
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}

        with torch.no_grad():
            outputs = self.model(**inputs)
            probabilities = torch.softmax(outputs.logits, dim=-1)

        # Convert to numpy and get predictions
        probs = probabilities.cpu().numpy()[0]
        predicted_class = np.argmax(probs)
        confidence = probs[predicted_class]

        # Enhanced rule-based analysis for specific abuse types
        abuse_analysis = self._analyze_abuse_patterns(text)

        return {
            'is_abusive': predicted_class == 1 or abuse_analysis['severity'] > 0.5,
            'confidence': float(max(confidence, abuse_analysis['severity'])),
            'abuse_type': abuse_analysis['primary_type'],
            'severity_score': abuse_analysis['severity'],
            'detailed_analysis': abuse_analysis
        }

    def _analyze_abuse_patterns(self, text: str) -> Dict:
        """Enhanced analysis for specific abuse patterns"""
        text_lower = text.lower()

        # Threat detection patterns
        threat_patterns = [
            'kill you', 'hurt you', 'destroy you', 'beat you', 'attack you',
            'going to harm', 'will hurt', 'threaten', 'make you pay'
        ]

        # Hate speech patterns
        hate_patterns = [
            'racial slurs', 'hate group', 'discriminatory', 'prejudiced'
        ]

        # Harassment patterns
        harassment_patterns = [
            'stalk', 'bully', 'intimidate', 'harass'
        ]

        severity = 0.0
        primary_type = 'none'

        # Check for threat patterns
        if any(pattern in text_lower for pattern in threat_patterns):
            severity = max(severity, 0.9)
            primary_type = 'threat'

        # Check for hate speech
        if any(pattern in text_lower for pattern in hate_patterns):
            severity = max(severity, 0.8)
            primary_type = 'hate_speech'

        # Check for harassment
        if any(pattern in text_lower for pattern in harassment_patterns):
            severity = max(severity, 0.7)
            primary_type = 'harassment'

        return {
            'primary_type': primary_type,
            'severity': severity,
            'patterns_found': len([p for p in threat_patterns + hate_patterns + harassment_patterns
                                   if p in text_lower])
        }