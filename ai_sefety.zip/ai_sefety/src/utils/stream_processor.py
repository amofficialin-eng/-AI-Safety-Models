import asyncio
import threading
import queue
import time
from datetime import datetime
from typing import Dict, List, Callable
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RealTimeProcessor:
    def __init__(self, max_queue_size=1000, processing_interval=0.1):
        self.message_queue = queue.Queue(maxsize=max_queue_size)
        self.processing_interval = processing_interval
        self.is_running = False
        self.processor_thread = None
        self.callbacks = []

        # Performance monitoring
        self.metrics = {
            'processed_messages': 0,
            'average_processing_time': 0,
            'queue_size_history': [],
            'error_count': 0
        }

    def add_message(self, message: Dict):
        """Add message to processing queue"""
        try:
            self.message_queue.put(message, block=False)
            logger.debug(f"Message added to queue: {message.get('user_id', 'unknown')}")
        except queue.Full:
            logger.warning("Message queue full, dropping message")
            self.metrics['error_count'] += 1

    def register_callback(self, callback: Callable):
        """Register callback for processed messages"""
        self.callbacks.append(callback)

    def start_processing(self):
        """Start the processing thread"""
        self.is_running = True
        self.processor_thread = threading.Thread(target=self._process_loop)
        self.processor_thread.daemon = True
        self.processor_thread.start()
        logger.info("Real-time processor started")

    def stop_processing(self):
        """Stop the processing thread"""
        self.is_running = False
        if self.processor_thread:
            self.processor_thread.join()
        logger.info("Real-time processor stopped")

    def _process_loop(self):
        """Main processing loop"""
        while self.is_running:
            try:
                # Process all available messages
                while not self.message_queue.empty():
                    message = self.message_queue.get_nowait()
                    self._process_single_message(message)

                # Update metrics
                self._update_metrics()

                # Sleep to prevent busy waiting
                time.sleep(self.processing_interval)

            except Exception as e:
                logger.error(f"Error in processing loop: {e}")
                self.metrics['error_count'] += 1
                time.sleep(1)  # Prevent tight error loop

    def _process_single_message(self, message: Dict):
        """Process a single message"""
        start_time = time.time()

        try:
            # Simulate processing (in real implementation, this would call the safety models)
            processed_result = {
                'user_id': message.get('user_id'),
                'message': message.get('text'),
                'timestamp': datetime.now().isoformat(),
                'processing_time': time.time() - start_time,
                'safety_checks': {
                    'abuse_detected': False,
                    'crisis_detected': False,
                    'content_filtered': False
                }
            }

            # Notify callbacks
            for callback in self.callbacks:
                try:
                    callback(processed_result)
                except Exception as e:
                    logger.error(f"Callback error: {e}")

            # Update metrics
            self.metrics['processed_messages'] += 1

        except Exception as e:
            logger.error(f"Error processing message: {e}")
            self.metrics['error_count'] += 1

        finally:
            processing_time = time.time() - start_time
            # Update average processing time (exponential moving average)
            alpha = 0.1
            self.metrics['average_processing_time'] = (
                    alpha * processing_time +
                    (1 - alpha) * self.metrics['average_processing_time']
            )

    def _update_metrics(self):
        """Update performance metrics"""
        current_queue_size = self.message_queue.qsize()
        self.metrics['queue_size_history'].append({
            'timestamp': datetime.now().isoformat(),
            'size': current_queue_size
        })

        # Keep only last 1000 entries
        if len(self.metrics['queue_size_history']) > 1000:
            self.metrics['queue_size_history'] = self.metrics['queue_size_history'][-1000:]

    def get_metrics(self) -> Dict:
        """Get current performance metrics"""
        return self.metrics.copy()


class BatchProcessor:
    def __init__(self, batch_size=32, timeout=0.5):
        self.batch_size = batch_size
        self.timeout = timeout
        self.current_batch = []
        self.last_batch_time = time.time()
        self.callbacks = []

    def add_message(self, message: Dict):
        """Add message to current batch"""
        self.current_batch.append(message)

        # Check if batch is ready for processing
        if (len(self.current_batch) >= self.batch_size or
                (time.time() - self.last_batch_time) >= self.timeout):
            self._process_batch()

    def register_callback(self, callback: Callable):
        """Register callback for processed batches"""
        self.callbacks.append(callback)

    def _process_batch(self):
        """Process the current batch"""
        if not self.current_batch:
            return

        batch_to_process = self.current_batch.copy()
        self.current_batch = []
        self.last_batch_time = time.time()

        # Process batch (in real implementation, this would use batch inference)
        batch_results = []
        for message in batch_to_process:
            result = {
                'user_id': message.get('user_id'),
                'message': message.get('text'),
                'batch_processed': True,
                'timestamp': datetime.now().isoformat()
            }
            batch_results.append(result)

        # Notify callbacks
        for callback in self.callbacks:
            try:
                callback(batch_results)
            except Exception as e:
                logger.error(f"Batch callback error: {e}")

        logger.info(f"Processed batch of {len(batch_to_process)} messages")