import pandas as pd
import numpy as np
from sklearn.utils import resample
from transformers import AutoTokenizer
import logging
from typing import List, Dict

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger.__name__


class BiasMitigator:
    def __init__(self):
        self.demographic_terms = {
            'gender_terms': ['he', 'she', 'him', 'her', 'his', 'hers', 'man', 'woman', 'boy', 'girl'],
            'racial_terms': ['black', 'white', 'asian', 'hispanic', 'latino', 'african', 'european'],
            'religious_terms': ['christian', 'muslim', 'jewish', 'hindu', 'buddhist', 'atheist'],
            'age_terms': ['young', 'old', 'elderly', 'teenager', 'senior', 'child']
        }

    def analyze_dataset_bias(self, dataset: pd.DataFrame, text_column: str, label_column: str) -> Dict:
        """Analyze potential biases in the dataset"""
        logger.info("Analyzing dataset for biases...")

        bias_report = {
            'demographic_representation': {},
            'label_balance': {},
            'potential_bias_indicators': []
        }

        # Analyze label distribution
        label_counts = dataset[label_column].value_counts()
        bias_report['label_balance'] = {
            'total_samples': len(dataset),
            'class_distribution': label_counts.to_dict(),
            'balance_ratio': label_counts.min() / label_counts.max() if len(label_counts) > 1 else 1.0
        }

        # Check for demographic term associations
        for category, terms in self.demographic_terms.items():
            category_bias = self._analyze_term_associations(dataset, text_column, label_column, terms)
            bias_report['demographic_representation'][category] = category_bias

            # Flag potential biases
            if category_bias['max_association_ratio'] > 2.0:
                bias_report['potential_bias_indicators'].append(
                    f"High association ratio in {category}: {category_bias['max_association_ratio']:.2f}"
                )

        return bias_report

    def _analyze_term_associations(self, dataset: pd.DataFrame, text_column: str,
                                   label_column: str, terms: List[str]) -> Dict:
        """Analyze associations between demographic terms and labels"""
        results = {}

        for term in terms:
            # Find samples containing the term
            term_mask = dataset[text_column].str.contains(term, case=False, na=False)
            term_samples = dataset[term_mask]

            if len(term_samples) > 0:
                # Calculate label distribution for term-containing samples
                term_label_dist = term_samples[label_column].value_counts(normalize=True)

                # Compare with overall distribution
                overall_dist = dataset[label_column].value_counts(normalize=True)

                # Calculate association ratios
                association_ratios = {}
                for label in overall_dist.index:
                    term_prob = term_label_dist.get(label, 0)
                    overall_prob = overall_dist.get(label, 0)

                    if overall_prob > 0:
                        association_ratios[label] = term_prob / overall_prob
                    else:
                        association_ratios[label] = 1.0

                results[term] = {
                    'sample_count': len(term_samples),
                    'association_ratios': association_ratios,
                    'max_association_ratio': max(association_ratios.values()) if association_ratios else 1.0
                }

        # Calculate overall metrics for the category
        if results:
            max_ratio = max(term_data['max_association_ratio'] for term_data in results.values())
            avg_ratio = np.mean([term_data['max_association_ratio'] for term_data in results.values()])
        else:
            max_ratio = 1.0
            avg_ratio = 1.0

        return {
            'terms_analyzed': len(terms),
            'terms_found': len(results),
            'max_association_ratio': max_ratio,
            'average_association_ratio': avg_ratio,
            'detailed_results': results
        }

    def apply_debiasing_techniques(self, dataset: pd.DataFrame, text_column: str,
                                   label_column: str, method: str = 'resampling') -> pd.DataFrame:
        """Apply debiasing techniques to the dataset"""
        logger.info(f"Applying {method} debiasing...")

        if method == 'resampling':
            return self._resample_dataset(dataset, label_column)
        elif method == 'reweighting':
            return self._reweight_dataset(dataset, label_column)
        else:
            logger.warning(f"Unknown debiasing method: {method}")
            return dataset

    def _resample_dataset(self, dataset: pd.DataFrame, label_column: str) -> pd.DataFrame:
        """Apply resampling to balance the dataset"""
        # Find the majority and minority classes
        label_counts = dataset[label_column].value_counts()
        max_count = label_counts.max()

        balanced_datasets = []

        for label in label_counts.index:
            label_data = dataset[dataset[label_column] == label]

            if len(label_data) < max_count:
                # Upsample minority class
                upsampled = resample(label_data,
                                     replace=True,
                                     n_samples=max_count,
                                     random_state=42)
                balanced_datasets.append(upsampled)
            else:
                balanced_datasets.append(label_data)

        return pd.concat(balanced_datasets, ignore_index=True)

    def _reweight_dataset(self, dataset: pd.DataFrame, label_column: str) -> pd.DataFrame:
        """Apply instance reweighting to balance class importance"""
        label_counts = dataset[label_column].value_counts()
        total_samples = len(dataset)

        # Calculate weights inversely proportional to class frequency
        weights = {}
        for label, count in label_counts.items():
            weights[label] = total_samples / (len(label_counts) * count)

        # Add weights to dataset
        dataset = dataset.copy()
        dataset['sample_weight'] = dataset[label_column].map(weights)

        return dataset


class FairnessMonitor:
    def __init__(self):
        self.performance_metrics = {}
        self.fairness_thresholds = {
            'demographic_parity': 0.8,
            'equal_opportunity': 0.8,
            'predictive_equality': 0.8
        }

    def monitor_model_fairness(self, predictions: List, true_labels: List,
                               sensitive_attributes: List) -> Dict:
        """Monitor model fairness across sensitive attributes"""

        fairness_report = {
            'overall_performance': {},
            'group_performance': {},
            'fairness_metrics': {},
            'bias_alerts': []
        }

        # Calculate overall performance
        accuracy = sum(1 for i in range(len(predictions))
                       if predictions[i] == true_labels[i]) / len(predictions)

        fairness_report['overall_performance']['accuracy'] = accuracy

        # Analyze performance by sensitive group
        unique_groups = set(sensitive_attributes)

        for group in unique_groups:
            group_mask = [attr == group for attr in sensitive_attributes]
            group_predictions = [p for i, p in enumerate(predictions) if group_mask[i]]
            group_true_labels = [t for i, t in enumerate(true_labels) if group_mask[i]]

            if group_predictions and group_true_labels:
                group_accuracy = sum(1 for i in range(len(group_predictions))
                                     if group_predictions[i] == group_true_labels[i]) / len(group_predictions)

                fairness_report['group_performance'][group] = {
                    'accuracy': group_accuracy,
                    'sample_size': len(group_predictions)
                }

        # Calculate fairness metrics
        fairness_metrics = self._calculate_fairness_metrics(
            predictions, true_labels, sensitive_attributes
        )
        fairness_report['fairness_metrics'] = fairness_metrics

        # Generate bias alerts
        for metric, value in fairness_metrics.items():
            if value < self.fairness_thresholds.get(metric, 0.8):
                fairness_report['bias_alerts'].append(
                    f"Low {metric}: {value:.3f} (threshold: {self.fairness_thresholds[metric]})"
                )

        return fairness_report

    def _calculate_fairness_metrics(self, predictions: List, true_labels: List,
                                    sensitive_attributes: List) -> Dict:
        """Calculate various fairness metrics"""
        # This is a simplified implementation
        # In production, you would implement proper fairness metrics

        unique_groups = set(sensitive_attributes)
        group_accuracies = {}

        for group in unique_groups:
            group_mask = [attr == group for attr in sensitive_attributes]
            group_predictions = [p for i, p in enumerate(predictions) if group_mask[i]]
            group_true_labels = [t for i, t in enumerate(true_labels) if group_mask[i]]

            if group_predictions and group_true_labels:
                accuracy = sum(1 for i in range(len(group_predictions))
                               if group_predictions[i] == group_true_labels[i]) / len(group_predictions)
                group_accuracies[group] = accuracy

        if group_accuracies:
            min_accuracy = min(group_accuracies.values())
            max_accuracy = max(group_accuracies.values())
            fairness_ratio = min_accuracy / max_accuracy if max_accuracy > 0 else 0
        else:
            fairness_ratio = 1.0

        return {
            'demographic_parity': fairness_ratio,
            'equal_opportunity': fairness_ratio,
            'predictive_equality': fairness_ratio,
            'min_group_accuracy': min_accuracy if group_accuracies else 0,
            'max_group_accuracy': max_accuracy if group_accuracies else 0
        }