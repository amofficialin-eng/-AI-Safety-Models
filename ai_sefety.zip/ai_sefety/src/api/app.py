from flask import Flask, request, jsonify
from models.abuse_detector import AbuseDetector
from models.escalation_detector import EscalationDetector
from models.crisis_intervention import CrisisIntervention
from models.content_filter import ContentFilter
from datetime import datetime
import logging

app = Flask(__name__)


class AISafetySystem:
    def __init__(self):
        self.abuse_detector = AbuseDetector()
        self.escalation_detector = EscalationDetector()
        self.crisis_intervention = CrisisIntervention()
        self.content_filter = ContentFilter()

        # User session management
        self.user_sessions = {}

        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def process_message(self, user_id: str, message: str, user_age: int = 18,
                        guardian_mode: bool = False) -> Dict:
        """Process a single message through all safety models"""

        # Content filtering first
        content_result = self.content_filter.filter_content(message, user_age, guardian_mode)

        # Abuse detection
        abuse_result = self.abuse_detector.predict(message)

        # Update conversation history for escalation detection
        if user_id not in self.user_sessions:
            self.user_sessions[user_id] = []

        conversation_entry = {
            'text': message,
            'timestamp': datetime.now(),
            'abuse_detected': abuse_result['is_abusive'],
            'abuse_confidence': abuse_result['confidence']
        }

        self.user_sessions[user_id].append(conversation_entry)

        # Escalation detection
        escalation_result = self.escalation_detector.analyze_conversation_flow(
            user_id, self.user_sessions[user_id]
        )

        # Crisis intervention assessment
        crisis_result = self.crisis_intervention.assess_crisis_level(
            message, self.user_sessions[user_id]
        )

        # Determine overall safety status
        safety_status = self._determine_safety_status(
            abuse_result, escalation_result, crisis_result, content_result
        )

        # Log safety event if concerning
        if safety_status['concern_level'] != 'low':
            self._log_safety_event(user_id, message, safety_status)

        return {
            'user_id': user_id,
            'timestamp': datetime.now().isoformat(),
            'processed_message': content_result['filtered_text'],
            'safety_status': safety_status,
            'model_results': {
                'content_filtering': content_result,
                'abuse_detection': abuse_result,
                'escalation_detection': escalation_result,
                'crisis_intervention': crisis_result
            },
            'actions_required': safety_status['actions_required']
        }

    def _determine_safety_status(self, abuse_result: Dict, escalation_result: Dict,
                                 crisis_result: Dict, content_result: Dict) -> Dict:
        """Determine overall safety status based on all model results"""

        concern_level = 'low'
        actions_required = []

        # Check for immediate crisis
        if crisis_result['intervention_level'] == 'immediate':
            concern_level = 'critical'
            actions_required.append('IMMEDIATE_HUMAN_INTERVENTION')
            actions_required.append('CRISIS_RESOURCES_PROVIDED')

        # Check for high abuse or escalation
        elif (abuse_result['is_abusive'] and abuse_result['confidence'] > 0.8) or \
                (escalation_result['is_escalating'] and escalation_result['confidence'] > 0.8):
            concern_level = 'high'
            actions_required.append('HUMAN_REVIEW_REQUIRED')
            actions_required.append('CONVERSATION_MONITORING')

        # Check for moderate concerns
        elif (abuse_result['is_abusive'] and abuse_result['confidence'] > 0.6) or \
                (escalation_result['is_escalating'] and escalation_result['confidence'] > 0.6) or \
                (crisis_result['risk_score'] > 0.5):
            concern_level = 'moderate'
            actions_required.append('ENHANCED_MONITORING')

        # Check content filtering issues
        elif not content_result['is_appropriate']:
            concern_level = 'moderate' if content_result['needs_review'] else 'low'
            if content_result['needs_review']:
                actions_required.append('CONTENT_REVIEW_REQUIRED')

        return {
            'concern_level': concern_level,
            'actions_required': actions_required,
            'summary': f"Safety concern level: {concern_level.upper()}"
        }

    def _log_safety_event(self, user_id: str, message: str, safety_status: Dict):
        """Log safety events for monitoring and analysis"""
        self.logger.warning(
            f"SAFETY_EVENT - User: {user_id}, "
            f"Level: {safety_status['concern_level']}, "
            f"Actions: {safety_status['actions_required']}, "
            f"Message: {message[:100]}..."
        )


# Initialize the safety system
safety_system = AISafetySystem()


@app.route('/api/safety/analyze', methods=['POST'])
def analyze_message():
    """API endpoint to analyze message for safety concerns"""
    try:
        data = request.get_json()

        user_id = data.get('user_id', 'anonymous')
        message = data.get('message', '')
        user_age = data.get('user_age', 18)
        guardian_mode = data.get('guardian_mode', False)

        if not message:
            return jsonify({'error': 'Message is required'}), 400

        result = safety_system.process_message(user_id, message, user_age, guardian_mode)

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/safety/status', methods=['GET'])
def system_status():
    """API endpoint to check system status"""
    return jsonify({
        'status': 'operational',
        'models_loaded': True,
        'timestamp': datetime.now().isoformat()
    })


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)