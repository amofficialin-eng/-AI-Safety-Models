import numpy as np
from typing import List, Dict
from datetime import datetime, timedelta


class EscalationDetector:
    def __init__(self):
        self.conversation_history = {}
        self.escalation_threshold = 0.7
        self.time_window = timedelta(minutes=10)

        # Emotional intensity indicators
        self.intensity_indicators = {
            'high': ['hate', 'kill', 'destroy', 'worthless', 'useless', 'despise'],
            'medium': ['angry', 'furious', 'annoying', 'stupid', 'idiot'],
            'low': ['upset', 'sad', 'disappointed', 'frustrated']
        }

    def analyze_conversation_flow(self, user_id: str, messages: List[Dict]) -> Dict:
        """Analyze conversation for escalation patterns"""
        if user_id not in self.conversation_history:
            self.conversation_history[user_id] = []

        current_message = messages[-1] if messages else {}

        # Add timestamp
        current_message['timestamp'] = datetime.now()
        self.conversation_history[user_id].append(current_message)

        # Filter recent messages
        recent_messages = self._get_recent_messages(user_id)

        if len(recent_messages) < 2:
            return {'is_escalating': False, 'confidence': 0.0, 'trend': 'stable'}

        # Calculate escalation metrics
        intensity_trend = self._calculate_intensity_trend(recent_messages)
        repetition_score = self._calculate_repetition_score(recent_messages)
        negativity_trend = self._calculate_negativity_trend(recent_messages)

        # Combined escalation score
        escalation_score = (intensity_trend * 0.4 +
                            repetition_score * 0.3 +
                            negativity_trend * 0.3)

        is_escalating = escalation_score > self.escalation_threshold

        return {
            'is_escalating': is_escalating,
            'confidence': float(escalation_score),
            'escalation_score': float(escalation_score),
            'intensity_trend': float(intensity_trend),
            'repetition_score': float(repetition_score),
            'negativity_trend': float(negativity_trend),
            'message_count': len(recent_messages)
        }

    def _get_recent_messages(self, user_id: str) -> List[Dict]:
        """Get messages from the last time window"""
        now = datetime.now()
        return [msg for msg in self.conversation_history[user_id]
                if now - msg['timestamp'] <= self.time_window]

    def _calculate_intensity_trend(self, messages: List[Dict]) -> float:
        """Calculate trend in emotional intensity"""
        if len(messages) < 2:
            return 0.0

        intensities = []
        for msg in messages:
            text = msg.get('text', '').lower()
            intensity = 0.0

            # Check for high intensity words
            if any(word in text for word in self.intensity_indicators['high']):
                intensity = 1.0
            elif any(word in text for word in self.intensity_indicators['medium']):
                intensity = 0.6
            elif any(word in text for word in self.intensity_indicators['low']):
                intensity = 0.3

            intensities.append(intensity)

        # Calculate trend (slope of intensity over time)
        if len(intensities) >= 3:
            x = np.arange(len(intensities))
            slope = np.polyfit(x, intensities, 1)[0]
            return max(0.0, min(1.0, slope * len(intensities)))

        return 0.0

    def _calculate_repetition_score(self, messages: List[Dict]) -> float:
        """Calculate repetition of aggressive language"""
        if len(messages) < 2:
            return 0.0

        recent_texts = [msg.get('text', '').lower() for msg in messages[-5:]]

        # Count repeated aggressive phrases
        aggressive_phrases = set()
        repetition_count = 0

        for text in recent_texts:
            phrases = self._extract_aggressive_phrases(text)
            for phrase in phrases:
                if phrase in aggressive_phrases:
                    repetition_count += 1
                aggressive_phrases.add(phrase)

        return min(1.0, repetition_count / 5)

    def _calculate_negativity_trend(self, messages: List[Dict]) -> float:
        """Calculate trend in negativity"""
        if len(messages) < 2:
            return 0.0

        negativity_scores = []
        negative_words = ['hate', 'angry', 'stupid', 'idiot', 'worthless', 'useless']

        for msg in messages:
            text = msg.get('text', '').lower()
            score = sum(1 for word in negative_words if word in text) / len(negative_words)
            negativity_scores.append(min(1.0, score))

        # Calculate trend
        if len(negativity_scores) >= 3:
            x = np.arange(len(negativity_scores))
            slope = np.polyfit(x, negativity_scores, 1)[0]
            return max(0.0, min(1.0, slope * len(negativity_scores)))

        return 0.0

    def _extract_aggressive_phrases(self, text: str) -> List[str]:
        """Extract potentially aggressive phrases from text"""
        words = text.split()
        aggressive_phrases = []

        # Look for adjective-noun combinations that could be aggressive
        aggressive_adjectives = ['stupid', 'idiot', 'worthless', 'useless', 'horrible']

        for i, word in enumerate(words):
            if word in aggressive_adjectives and i + 1 < len(words):
                aggressive_phrases.append(f"{word} {words[i + 1]}")

        return aggressive_phrases