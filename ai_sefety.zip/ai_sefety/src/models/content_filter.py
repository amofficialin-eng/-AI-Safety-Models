from typing import Dict, List
import re


class ContentFilter:
    def __init__(self):
        # Age-appropriate content categories
        self.age_categories = {
            'child': {'min_age': 0, 'max_age': 12},
            'teen': {'min_age': 13, 'max_age': 17},
            'adult': {'min_age': 18, 'max_age': 100}
        }

        # Content restriction levels
        self.restricted_content = {
            'violence': {
                'child': ['graphic violence', 'weapons', 'physical harm'],
                'teen': ['extreme violence', 'graphic descriptions'],
                'adult': []  # No restrictions for adults
            },
            'substances': {
                'child': ['alcohol', 'drugs', 'substance abuse'],
                'teen': ['glorifying substance use'],
                'adult': []
            },
            'sexual_content': {
                'child': ['sexual content', 'explicit relationships'],
                'teen': ['explicit sexual content'],
                'adult': []
            },
            'language': {
                'child': ['profanity', 'offensive language'],
                'teen': ['extreme profanity', 'hate speech'],
                'adult': []
            }
        }

        # Specific blocked terms by age group
        self.blocked_terms = {
            'child': [
                'kill', 'murder', 'drugs', 'alcohol', 'sex', 'porn', 'damn', 'hell'
            ],
            'teen': [
                'graphic violence', 'hard drugs', 'explicit sex'
            ]
        }

    def filter_content(self, text: str, user_age: int, guardian_mode: bool = False) -> Dict:
        """Filter content based on age appropriateness"""
        age_group = self._get_age_group(user_age)

        if age_group == 'adult' and not guardian_mode:
            return {
                'is_appropriate': True,
                'filtered_text': text,
                'age_group': age_group,
                'blocked_categories': [],
                'needs_review': False
            }

        analysis = self._analyze_content(text, age_group)
        is_appropriate = len(analysis['blocked_categories']) == 0

        # Apply filtering if needed
        filtered_text = self._apply_filtering(text, age_group) if not is_appropriate else text

        return {
            'is_appropriate': is_appropriate,
            'filtered_text': filtered_text,
            'age_group': age_group,
            'blocked_categories': analysis['blocked_categories'],
            'needs_review': analysis['needs_review'],
            'content_warnings': analysis['content_warnings']
        }

    def _get_age_group(self, age: int) -> str:
        """Determine age group based on age"""
        for group, range in self.age_categories.items():
            if range['min_age'] <= age <= range['max_age']:
                return group
        return 'adult'

    def _analyze_content(self, text: str, age_group: str) -> Dict:
        """Analyze content for age-appropriateness"""
        text_lower = text.lower()
        blocked_categories = []
        content_warnings = []
        needs_review = False

        # Check each content category
        for category, restrictions in self.restricted_content.items():
            if age_group in restrictions and restrictions[age_group]:
                # Check if restricted content is present
                for restricted_item in restrictions[age_group]:
                    if restricted_item in text_lower:
                        blocked_categories.append(category)
                        content_warnings.append(f"Contains {category}: {restricted_item}")

        # Check for blocked terms
        if age_group in self.blocked_terms:
            for term in self.blocked_terms[age_group]:
                if term in text_lower:
                    blocked_categories.append('blocked_terms')
                    content_warnings.append(f"Contains blocked term: {term}")
                    needs_review = True

        return {
            'blocked_categories': list(set(blocked_categories)),
            'content_warnings': content_warnings,
            'needs_review': needs_review
        }

    def _apply_filtering(self, text: str, age_group: str) -> str:
        """Apply content filtering to text"""
        filtered_text = text

        # Replace blocked terms with [REDACTED]
        if age_group in self.blocked_terms:
            for term in self.blocked_terms[age_group]:
                pattern = re.compile(re.escape(term), re.IGNORECASE)
                filtered_text = pattern.sub('[REDACTED]', filtered_text)

        return filtered_text