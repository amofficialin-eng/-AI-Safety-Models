import re
from typing import Dict, List


class CrisisIntervention:
    def __init__(self):
        # Self-harm and crisis indicators
        self.crisis_indicators = {
            'self_harm_immediate': [
                r'kill myself', r'end it all', r'suicide', r'want to die',
                r'no reason to live', r'better off dead', r'going to harm myself'
            ],
            'self_harm_ideation': [
                r'don\'t want to live', r'can\'t go on', r'life is pointless',
                r'nothing matters', r'hopeless', r'helpless'
            ],
            'severe_distress': [
                r'can\'t cope', r'overwhelmed', r'breaking down', r'lost control',
                r'panic attack', r'anxiety attack', r'can\'t breathe'
            ],
            'isolation': [
                r'alone', r'nobody cares', r'no one understands', r'isolated'
            ]
        }

        self.crisis_resources = {
            'immediate': {
                'action': 'IMMEDIATE_HUMAN_INTERVENTION',
                'message': 'Please know you are not alone. I\'m connecting you with someone who can help right now.',
                'resources': [
                    'National Suicide Prevention Lifeline: 1-800-273-8255',
                    'Crisis Text Line: Text HOME to 741741',
                    'Emergency Services: 911'
                ]
            },
            'high_risk': {
                'action': 'URGENT_HUMAN_INTERVENTION',
                'message': 'I\'m very concerned about what you\'re sharing. Let me connect you with a trained helper.',
                'resources': [
                    'National Suicide Prevention Lifeline: 1-800-273-8255',
                    'Crisis Text Line: Text HOME to 741741'
                ]
            },
            'moderate_risk': {
                'action': 'SCHEDULED_INTERVENTION',
                'message': 'It sounds like you\'re going through a difficult time. Would you like to talk with someone who can help?',
                'resources': [
                    'Mental Health America: 1-800-273-TALK',
                    'SAMHSA Helpline: 1-800-662-4357'
                ]
            }
        }

    def assess_crisis_level(self, text: str, conversation_history: List[Dict] = None) -> Dict:
        """Assess crisis level and determine intervention needed"""
        text_lower = text.lower()

        # Check for immediate self-harm indicators
        immediate_risk = any(re.search(pattern, text_lower)
                             for pattern in self.crisis_indicators['self_harm_immediate'])

        # Check for self-harm ideation
        ideation_risk = any(re.search(pattern, text_lower)
                            for pattern in self.crisis_indicators['self_harm_ideation'])

        # Check for severe distress
        distress_risk = any(re.search(pattern, text_lower)
                            for pattern in self.crisis_indicators['severe_distress'])

        # Check for isolation statements
        isolation_risk = any(re.search(pattern, text_lower)
                             for pattern in self.crisis_indicators['isolation'])

        # Calculate risk score
        risk_score = 0.0
        if immediate_risk:
            risk_score = 1.0
        elif ideation_risk:
            risk_score = 0.8
        elif distress_risk and isolation_risk:
            risk_score = 0.7
        elif distress_risk:
            risk_score = 0.5

        # Determine intervention level
        if risk_score >= 0.9:
            intervention_level = 'immediate'
        elif risk_score >= 0.7:
            intervention_level = 'high_risk'
        elif risk_score >= 0.5:
            intervention_level = 'moderate_risk'
        else:
            intervention_level = 'low_risk'

        return {
            'crisis_detected': risk_score > 0.3,
            'risk_score': risk_score,
            'intervention_level': intervention_level,
            'intervention_details': self.crisis_resources.get(intervention_level, {}),
            'triggers_found': {
                'immediate_self_harm': immediate_risk,
                'self_harm_ideation': ideation_risk,
                'severe_distress': distress_risk,
                'isolation': isolation_risk
            }
        }