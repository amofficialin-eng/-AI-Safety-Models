import pandas as pd
import numpy as np
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    precision_recall_curve,
    roc_curve,
    auc,
    precision_score,
    recall_score,
    f1_score
)
import matplotlib.pyplot as plt
import seaborn as sns
from models.abuse_detector import AbuseDetector
from models.escalation_detector import EscalationDetector
from models.crisis_intervention import CrisisIntervention
from models.content_filter import ContentFilter
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ModelEvaluator:
    def __init__(self):
        self.abuse_detector = AbuseDetector()
        self.escalation_detector = EscalationDetector()
        self.crisis_intervention = CrisisIntervention()
        self.content_filter = ContentFilter()

    def evaluate_abuse_detection(self, test_data_path=None):
        """Evaluate abuse detection model"""
        logger.info("Evaluating abuse detection model...")

        if test_data_path:
            test_data = pd.read_csv(test_data_path)
        else:
            test_data = self._create_test_abuse_data()

        y_true = []
        y_pred = []
        y_scores = []

        for _, row in test_data.iterrows():
            text = row['text']
            true_label = row['label']

            result = self.abuse_detector.predict(text)
            predicted_label = 1 if result['is_abusive'] else 0
            confidence = result['confidence']

            y_true.append(true_label)
            y_pred.append(predicted_label)
            y_scores.append(confidence)

        # Calculate metrics
        metrics = self._calculate_classification_metrics(y_true, y_pred, y_scores)

        # Generate plots
        self._plot_confusion_matrix(y_true, y_pred, "Abuse Detection")
        self._plot_roc_curve(y_true, y_scores, "Abuse Detection")

        return metrics

    def evaluate_crisis_detection(self, test_data_path=None):
        """Evaluate crisis intervention model"""
        logger.info("Evaluating crisis intervention model...")

        if test_data_path:
            test_data = pd.read_csv(test_data_path)
        else:
            test_data = self._create_test_crisis_data()

        y_true = []
        y_pred = []
        y_scores = []

        for _, row in test_data.iterrows():
            text = row['text']
            true_label = row['crisis_label']

            result = self.crisis_intervention.assess_crisis_level(text)
            predicted_label = 1 if result['crisis_detected'] else 0
            risk_score = result['risk_score']

            y_true.append(true_label)
            y_pred.append(predicted_label)
            y_scores.append(risk_score)

        metrics = self._calculate_classification_metrics(y_true, y_pred, y_scores)

        self._plot_confusion_matrix(y_true, y_pred, "Crisis Detection")
        self._plot_roc_curve(y_true, y_scores, "Crisis Detection")

        return metrics

    def evaluate_content_filtering(self, test_data_path=None):
        """Evaluate content filtering model"""
        logger.info("Evaluating content filtering...")

        if test_data_path:
            test_data = pd.read_csv(test_data_path)
        else:
            test_data = self._create_test_content_data()

        results = []

        for _, row in test_data.iterrows():
            text = row['text']
            user_age = row['user_age']
            should_block = row['should_block']

            result = self.content_filter.filter_content(text, user_age, guardian_mode=True)
            actually_blocked = not result['is_appropriate']

            results.append({
                'text': text,
                'user_age': user_age,
                'should_block': should_block,
                'actually_blocked': actually_blocked,
                'correct': should_block == actually_blocked
            })

        accuracy = sum(r['correct'] for r in results) / len(results)

        # Calculate precision and recall for blocking
        true_positives = sum(1 for r in results if r['should_block'] and r['actually_blocked'])
        false_positives = sum(1 for r in results if not r['should_block'] and r['actually_blocked'])
        false_negatives = sum(1 for r in results if r['should_block'] and not r['actually_blocked'])

        precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
        recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'true_positives': true_positives,
            'false_positives': false_positives,
            'false_negatives': false_negatives
        }

    def evaluate_escalation_detection(self):
        """Evaluate escalation detection with simulated conversations"""
        logger.info("Evaluating escalation detection...")

        # Test scenarios
        scenarios = [
            {
                'name': 'Non-escalating conversation',
                'messages': [
                    "Hello, how are you?",
                    "I'm doing well, thanks for asking.",
                    "That's good to hear. How can I help you?",
                    "I have a question about my account."
                ],
                'should_escalate': False
            },
            {
                'name': 'Escalating conversation',
                'messages': [
                    "This is frustrating.",
                    "I'm getting really angry now.",
                    "Why is this not working? I hate this!",
                    "I can't believe how stupid this system is!"
                ],
                'should_escalate': True
            },
            {
                'name': 'Mixed conversation',
                'messages': [
                    "Hi there",
                    "I need some help",
                    "This is annoying me",
                    "Actually, never mind, I figured it out"
                ],
                'should_escalate': False
            }
        ]

        results = []

        for scenario in scenarios:
            user_id = f"test_user_{scenario['name'].replace(' ', '_').lower()}"
            escalation_detected = False
            max_confidence = 0

            # Simulate conversation
            for message in scenario['messages']:
                conversation_entry = {'text': message}
                result = self.escalation_detector.analyze_conversation_flow(
                    user_id, [conversation_entry]
                )

                if result['is_escalating']:
                    escalation_detected = True
                    max_confidence = max(max_confidence, result['confidence'])

            correct = escalation_detected == scenario['should_escalate']
            results.append({
                'scenario': scenario['name'],
                'expected_escalation': scenario['should_escalate'],
                'detected_escalation': escalation_detected,
                'confidence': max_confidence,
                'correct': correct
            })

        accuracy = sum(r['correct'] for r in results) / len(results)

        return {
            'accuracy': accuracy,
            'scenario_results': results
        }

    def _calculate_classification_metrics(self, y_true, y_pred, y_scores):
        """Calculate comprehensive classification metrics"""

        # Basic metrics
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        accuracy = sum(1 for i in range(len(y_true)) if y_true[i] == y_pred[i]) / len(y_true)

        # ROC curve metrics
        fpr, tpr, thresholds = roc_curve(y_true, y_scores)
        roc_auc = auc(fpr, tpr)

        # Precision-recall curve
        precision_curve, recall_curve, _ = precision_recall_curve(y_true, y_scores)
        pr_auc = auc(recall_curve, precision_curve)

        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'roc_auc': roc_auc,
            'pr_auc': pr_auc,
            'confusion_matrix': confusion_matrix(y_true, y_pred).tolist()
        }

    def _plot_confusion_matrix(self, y_true, y_pred, title):
        """Plot confusion matrix"""
        cm = confusion_matrix(y_true, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title(f'Confusion Matrix - {title}')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.savefig(f'confusion_matrix_{title.replace(" ", "_").lower()}.png')
        plt.close()

    def _plot_roc_curve(self, y_true, y_scores, title):
        """Plot ROC curve"""
        fpr, tpr, _ = roc_curve(y_true, y_scores)
        roc_auc = auc(fpr, tpr)

        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (area = {roc_auc:.2f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title(f'ROC Curve - {title}')
        plt.legend(loc="lower right")
        plt.savefig(f'roc_curve_{title.replace(" ", "_").lower()}.png')
        plt.close()

    def _create_test_abuse_data(self):
        """Create test data for abuse detection"""
        test_data = [
            {"text": "I hate you, you're stupid!", "label": 1},
            {"text": "Hello, how are you today?", "label": 0},
            {"text": "You're worthless and should disappear!", "label": 1},
            {"text": "Thanks for your help with this.", "label": 0},
            {"text": "I'm going to hurt you!", "label": 1},
            {"text": "Can you please explain that again?", "label": 0},
            {"text": "You're a pathetic loser!", "label": 1},
            {"text": "I appreciate your assistance.", "label": 0},
            {"text": "I'll make you pay for this!", "label": 1},
            {"text": "Have a wonderful day!", "label": 0}
        ]
        return pd.DataFrame(test_data)

    def _create_test_crisis_data(self):
        """Create test data for crisis detection"""
        test_data = [
            {"text": "I want to kill myself", "crisis_label": 1},
            {"text": "Hello, how are you?", "crisis_label": 0},
            {"text": "I can't go on anymore", "crisis_label": 1},
            {"text": "The weather is nice today", "crisis_label": 0},
            {"text": "I'm going to end it all", "crisis_label": 1},
            {"text": "Can you help me with this task?", "crisis_label": 0},
            {"text": "Nobody cares if I live or die", "crisis_label": 1},
            {"text": "I'm learning so much", "crisis_label": 0},
            {"text": "I feel hopeless and alone", "crisis_label": 1},
            {"text": "Thanks for your support", "crisis_label": 0}
        ]
        return pd.DataFrame(test_data)

    def _create_test_content_data(self):
        """Create test data for content filtering"""
        test_data = [
            {"text": "This is about drugs and alcohol", "user_age": 10, "should_block": True},
            {"text": "Hello, how are you?", "user_age": 10, "should_block": False},
            {"text": "Violent content with weapons", "user_age": 12, "should_block": True},
            {"text": "Learning is fun", "user_age": 12, "should_block": False},
            {"text": "Explicit sexual content", "user_age": 15, "should_block": True},
            {"text": "Science and technology news", "user_age": 15, "should_block": False},
            {"text": "Profanity and offensive language", "user_age": 8, "should_block": True},
            {"text": "Educational content for kids", "user_age": 8, "should_block": False},
            {"text": "Discussion about mature themes", "user_age": 17, "should_block": False},
            {"text": "Graphic violence description", "user_age": 17, "should_block": True}
        ]
        return pd.DataFrame(test_data)


def run_comprehensive_evaluation():
    """Run comprehensive evaluation of all models"""
    evaluator = ModelEvaluator()

    results = {}

    # Evaluate each model
    results['abuse_detection'] = evaluator.evaluate_abuse_detection()
    results['crisis_detection'] = evaluator.evaluate_crisis_detection()
    results['content_filtering'] = evaluator.evaluate_content_filtering()
    results['escalation_detection'] = evaluator.evaluate_escalation_detection()

    # Print results
    print("\n" + "=" * 60)
    print("COMPREHENSIVE MODEL EVALUATION RESULTS")
    print("=" * 60)

    for model_name, metrics in results.items():
        print(f"\n{model_name.upper().replace('_', ' ')}:")
        print("-" * 40)

        if model_name == 'escalation_detection':
            print(f"Accuracy: {metrics['accuracy']:.3f}")
            for scenario in metrics['scenario_results']:
                print(f"  {scenario['scenario']}: "
                      f"Expected={scenario['expected_escalation']}, "
                      f"Detected={scenario['detected_escalation']}, "
                      f"Correct={scenario['correct']}")
        else:
            for metric, value in metrics.items():
                if metric not in ['confusion_matrix']:
                    if isinstance(value, float):
                        print(f"  {metric}: {value:.3f}")
                    else:
                        print(f"  {metric}: {value}")

    # Save results to file
    with open('evaluation_results.json', 'w') as f:
        # Convert numpy types to Python types for JSON serialization
        def convert_types(obj):
            if isinstance(obj, (np.float32, np.float64)):
                return float(obj)
            elif isinstance(obj, (np.int32, np.int64)):
                return int(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, dict):
                return {k: convert_types(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_types(item) for item in obj]
            else:
                return obj

        json.dump(convert_types(results), f, indent=2)

    print(f"\nDetailed results saved to 'evaluation_results.json'")


if __name__ == "__main__":
    run_comprehensive_evaluation()